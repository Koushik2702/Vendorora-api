import React from "react";

const Register = () => {
  return (
    <div className="registerSection">
      <form className="authForm">
        <h3>Venor Regiter</h3>
        <label>UserName</label>
        <input type="text" placeholder="Enter Your userName" />
        <br />
        <label>Email</label>
        <input type="email" placeholder="Enter Your Email" />
        <br />
        <label>Password</label>
        <input type="password" placeholder="Enter Your Password" />
        <br />
        <div className="btnSubmit">
          <button>Submit</button>
        </div>
      </form>
    </div>
  );
};

export default Register;
