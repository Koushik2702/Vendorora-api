import React from 'react'

const AddFirm = () => {
  return (
    <div className="firmSection">
        <form className="tableForm">
            <h2>Add Firm</h2>
            <label>Firm Name</label>
            <input type='text'placeholder='Enter the Firmname'/>
            <label>Area</label>
            <input type='text'placeholder='Enter the Area'/>
            <label>Category</label>
            <input type='text'placeholder='Enter the Category'/>
            <label>Region</label>
            <input type='text'placeholder='Enter the Region'/>
            <label>Offer</label>
            <input type='text'placeholder='Enter the Offer'/>
            <label>Firm Image</label>
            <input type='file'/>
            <br/>
            <div className="btnSubmit">
               <button>Submit</button>
            </div>
        </form>
    </div>
  )
}

export default AddFirm
