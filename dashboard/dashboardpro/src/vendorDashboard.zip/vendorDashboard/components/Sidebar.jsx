import React from 'react'

const Sidebar = () => {
  return (
    <div className='sideBarSection'>
        <ul>
            <li>Add Firm</li>
            <li>Add Product</li>
            <li>All Products</li>
            <li>User Details</li>
        </ul>
      
    </div>
  )
}

export default Sidebar
