import React from 'react'
import NavBar from '../components/NavBar'

import Login from '../components/forms/Login'
import Sidebar from '../components/Sidebar'
import Register from '../components/forms/Register'
import AddFirm from '../components/forms/AddFirm'
import AddProduct from '../components/forms/AddProduct'

const LandingPage = () => {
  return (
    <>
      <section className='landingSection'>
        <NavBar/>
         <div className='collectionSection'>
            <Sidebar/>
             {/* <Login/> */}
             {/* <Register/> */}
             {/* <AddFirm/> */}
             <AddProduct/>
          </div>
       
         
      </section>
    </>
  )
}

export default LandingPage
